from flask import Flask, request, jsonify
from datetime import datetime, timezone

app = Flask(__name__)

orders = []
telemetry_records = []

@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "Order and Telemetry API",
        "status": "running"
    })

@app.route("/orders", methods=["POST"])
def create_order():
    data = request.get_json(silent=True) or {}

    order = {
        "order_id": len(orders) + 1,
        "product": data.get("product"),
        "quantity": data.get("quantity"),
        "created_at": datetime.now(timezone.utc).isoformat()
    }

    orders.append(order)
    return jsonify(order), 201

@app.route("/orders", methods=["GET"])
def get_orders():
    return jsonify(orders)

@app.route("/telemetry", methods=["POST"])
def receive_telemetry():
    data = request.get_json(silent=True) or {}

    record = {
        "record_id": len(telemetry_records) + 1,
        "device_id": data.get("device_id"),
        "activity": data.get("activity"),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    telemetry_records.append(record)
    return jsonify(record), 201

@app.route("/telemetry", methods=["GET"])
def get_telemetry():
    return jsonify(telemetry_records)

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port, debug=False)